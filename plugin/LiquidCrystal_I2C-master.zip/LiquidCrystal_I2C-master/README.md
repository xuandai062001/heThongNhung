# LiquidCrystal_I2C
Thư viện cho Led LCD I2C 16x2
wiki doc http://www.dfrobot.com/wiki/index.php?title=I2C/TWI_LCD1602_Module_(SKU:_DFR0063)
Support Forum: http://www.dfrobot.com/forum/
Compatible with the Arduino IDE 1.0
Library version:1.1
